﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class ScoreBoard : MonoBehaviour
{

    public static ScoreBoard instance;

    public Text player1Text;
    public Text player2Text;

    public int player1;
    public int player2;

    public bool lastLevel;

    // Use this for initialization
    void Start()
    {

        instance = this;
        player1 = player2 = 0;
    }

    // Update is called once per frame
    void Update()
    {


    }

    public void LoadNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void Player1ScorePoint()
    {

        player1 += 1;

        player1Text.text = player1.ToString();

        if (lastLevel)
        {
            if (player1 > 3)
            {

                SceneManager.LoadScene("Player1Vic");
            }
        }
        else
        {
            if (player1 >= 3)
            {
                LoadNextLevel();
            }
        }
    }
    
        public void Player2ScorePoint()
        {

        player2 += 1;

        player2Text.text = player2.ToString();

        if (lastLevel)
        {
            if (player2 > 3)
            {

                SceneManager.LoadScene("Player2Vic");
            }
        }
        else
        {
            if(player2 >= 3)
            {
                LoadNextLevel();
            }
            
        }
    }

}
