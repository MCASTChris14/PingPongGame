﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControls : MonoBehaviour
{

    //Player 1 Controls => W/S keys
    //Player 2 Controls => Mouse0/Mouse1 keys

    public GameObject Player1;
    public GameObject Player2;

    // Use this for initialization
    void Start()
    {



    }

    // Update is called once per frame
    void Update()
    {

        Player1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 0f, 0f);

        if (Input.GetKey(KeyCode.W))
        {
            Player1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 6f, 0f);
        }
        else if (Input.GetKey(KeyCode.S))
        {
            Player1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -6f, 0f);
        }

        Player2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 0f, 0f);

        if (Input.GetKey(KeyCode.Mouse0))
        {
            Player2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 6f, 0f);
        }
        else if (Input.GetKey(KeyCode.Mouse1))
        {
            Player2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -6f, 0f);
        }


    }
}
