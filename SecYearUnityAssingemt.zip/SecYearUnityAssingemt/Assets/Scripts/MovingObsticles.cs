﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingObsticles: MonoBehaviour
{

    public GameObject brick1;
    public GameObject brick2;

    // Use this for initialization
    void Start()
    {

        brick1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -2f, 0f);
        brick2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 2f, 0f);

    }

    // Update is called once per frame
    void Update()
    {

        if (brick1.GetComponent<Rigidbody2D>().velocity.y < 0f)
        {
            brick1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -4, 0f);
        }
        if (brick1.GetComponent<Rigidbody2D>().velocity.y > 0f)
        {
            brick1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 4, 0f);
        }

        if (brick2.GetComponent<Rigidbody2D>().velocity.y < 0f)
        {
            brick2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -4, 0f);
        }
        if (brick2.GetComponent<Rigidbody2D>().velocity.y > 0f)
        {
            brick2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 4, 0f);
        }



    }
}
