﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{

    
    Rigidbody2D rigidb;


  
    void Start()
    {

        rigidb = GetComponent<Rigidbody2D>();

        StartCoroutine(Pause());


    }

 
    void Update()
    {

        
        if (transform.position.x < -12f)
        {

            transform.position = Vector3.zero;
            rigidb.velocity = Vector3.zero;

          
            ScoreBoard.instance.Player2ScorePoint();


            StartCoroutine(Pause());
        }


        
        if (transform.position.x > 12f)
        {

            transform.position = Vector3.zero;
            rigidb.velocity = Vector3.zero;


           ScoreBoard.instance.Player1ScorePoint();

            StartCoroutine(Pause());
        }


    }

    IEnumerator Pause()
    {


        
        yield return new WaitForSeconds(2.5f);

      
        LaunchBall();
    }

    void LaunchBall()
    {

        transform.position = Vector3.zero;

  

        
        int xDirection = Random.Range(0, 2);
        
        int yDirection = Random.Range(0, 3);


        Vector3 launchDirection = new Vector3();

        if (xDirection == 0)
        {

            launchDirection.x = -6f;
        }
        if (xDirection == 1)
        {

            launchDirection.x = 6f;
        }

       
        if (yDirection == 0)
        {

            launchDirection.y = -6f;
        }
        if (yDirection == 1)
        {

            launchDirection.y = 6f;
        }
        if (yDirection == 2)
        {

            launchDirection.y = 0f;
        }
        
        rigidb.velocity = launchDirection;
    }
    
    void OnCollisionEnter(Collision bump)
    {

        if (bump.gameObject.name == "TopBounds")
        {

            float speedInXDirection = 0f;

            if (rigidb.velocity.x > 0f)
                speedInXDirection = 8f;

            if (rigidb.velocity.x < 0f)
                speedInXDirection = -8f;

            rigidb.velocity = new Vector3(speedInXDirection, -8f, 0f);
        }

        if (bump.gameObject.name == "BottomBounds")
        {

            float speedInXDirection = 0f;

            if (rigidb.velocity.x > 0f)
                speedInXDirection = 8f;

            if (rigidb.velocity.x < 0f)
                speedInXDirection = -8f;

            rigidb.velocity = new Vector3(speedInXDirection, 8f, 0f);
        }

      
        if (bump.gameObject.name == "Left_Bat")
        {

            rigidb.velocity = new Vector3(13f, 0f, 0f);


           
            if (transform.position.y - bump.gameObject.transform.position.y < -1)
            {

                rigidb.velocity = new Vector3(8f, -8f, 0f);
            }
           
            if (transform.position.y - bump.gameObject.transform.position.y > 1)
            {

                rigidb.velocity = new Vector3(8f, 8f, 0f);
            }
        }
        if (bump.gameObject.name == "Right_Bat")
        {

            rigidb.velocity = new Vector3(-13f, 0f, 0f);


            
            if (transform.position.y - bump.gameObject.transform.position.y < -1)
            {

                rigidb.velocity = new Vector3(-8f, -8f, 0f);
            }
         
            if (transform.position.y - bump.gameObject.transform.position.y > 1)
            {

                rigidb.velocity = new Vector3(-8f, 8f, 0f);
            }
        }

    }

}

